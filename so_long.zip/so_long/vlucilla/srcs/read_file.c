/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   read_file.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/08 20:29:32 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/08 20:30:38 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong.h"

static char	*ft_join_free(char *s1, char *s2)
{
	char	*str;
	int		i;
	int		j;
	int		len;

	i = -1;
	if (!s1 && !s2)
		return (NULL);
	if (!s1)
		s1 = ft_strdup("\0");
	if (!s2)
		s2 = ft_strdup("\0");
	len = ft_strlen(s1) + ft_strlen(s2);
	str = (char *)malloc(sizeof(char) * (len + 1));
	if (!str)
		return (NULL);
	while (s1[++i])
		str[i] = s1[i];
	j = -1;
	while (s2[++j])
		str[i++] = s2[j];
	str[i] = '\0';
	free(s1);
	free(s2);
	return (str);
}

static char	*ft_join_n(char *s)
{
	char	*str;
	int		i;
	int		len;

	i = -1;
	if (!s)
		s = ft_strdup("");
	len = ft_strlen(s);
	str = (char *)malloc(sizeof(char) * (len + 2));
	if (!str)
		return (NULL);
	while (s[++i])
		str[i] = s[i];
	str[i] = '\n';
	str[len + 1] = '\0';
	free(s);
	return (str);
}

void	read_map(int fd, t_game *game)
{
	char	*line;

	line = NULL;
	while (get_next_line(fd, &line) > 0)
	{
		game->strmap = ft_join_free(game->strmap, line);
		game->strmap = ft_join_n(game->strmap);
		line = NULL;
	}
	game->strmap = ft_join_free(game->strmap, line);
	game->strmap = ft_join_n(game->strmap);
	line = NULL;
}
