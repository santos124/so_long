/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/08 21:19:55 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/08 21:19:57 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong.h"

static int	ft_clear(int fd, char **remainder)
{
	if (remainder[fd])
	{
		free(remainder[fd]);
		remainder[fd] = NULL;
	}
	return (-1);
}

static int	if_null(char **line, int red, int fd, char **remainder)
{
	*line = ft_strdup(remainder[fd]);
	if (!(*line))
		return (ft_clear(fd, remainder));
	ft_clear(fd, remainder);
	if (red == 0)
		return (0);
	return (1);
}

static int	check_remainder(char **line, int fd, char **remainder, int red)
{
	char	*tmp;
	int		len;

	len = 0;
	while (remainder[fd][len] != '\n' && remainder[fd][len] != '\0')
		len++;
	if (remainder[fd][len] == '\n')
	{
		*line = ft_substr(remainder[fd], 0, len);
		if (!(*line))
			return (ft_clear(fd, remainder));
		tmp = ft_strdup(remainder[fd] + len + 1);
		if (!tmp)
			return (ft_clear(fd, remainder));
		free(remainder[fd]);
		remainder[fd] = tmp;
		tmp = NULL;
	}
	else if (remainder[fd][len] == '\0')
		return (if_null(line, red, fd, remainder));
	return (1);
}

static void	new_iterr(char *remainder[256], int fd, char **tmp)
{
	free(remainder[fd]);
	remainder[fd] = *tmp;
	*tmp = NULL;
}

int	get_next_line(int fd, char **line)
{
	static char	*remainder[256];
	char		*buf;
	int			red;
	char		*tmp;

	buf = (char *)malloc(sizeof(char) * BUFFER_SIZE + 1);
	if (!buf)
		return (-1);
	if (remainder[fd] == NULL)
		remainder[fd] = ft_strdup("");
	red = read(fd, buf, BUFFER_SIZE);
	while (red > 0)
	{
		buf[red] = '\0';
		tmp = ft_strjoin(remainder[fd], buf);
		if (!tmp)
			return (ft_clear(fd, remainder));
		new_iterr(remainder, fd, &tmp);
		if (ft_strchr(remainder[fd], '\n'))
			break ;
		red = read(fd, buf, BUFFER_SIZE);
	}
	free(buf);
	return (check_remainder(line, fd, remainder, red));
}
