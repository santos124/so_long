/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/08 20:25:04 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/08 20:27:05 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong.h"

static void	init_game(t_game *game)
{
	game->empty = NULL;
	game->exit = NULL;
	game->plr = NULL;
	game->wall = NULL;
	game->collect = NULL;
	game->img = NULL;
	game->key = NULL;
	game->w_map = 0;
	game->h_map = 0;
	game->collect_count = 0;
	game->pl_x = 0;
	game->pl_y = 0;
	game->move = 0;
	game->mlx = NULL;
	game->win = NULL;
	game->map = NULL;
	game->strmap = NULL;
	game->file_name = NULL;
}

static int	open_file(t_game *game)
{
	int	fd;

	fd = open(game->file_name, O_RDWR);
	if (fd < 0)
		error_one("can't read the file.\n", game);
	read_map(fd, game);
	close(fd);
	if (!game->strmap)
		error_one("no map.\n", game);
	if (!create_map(game))
		error_one("incorrect map.\n", game);
	if (!is_valid_map(game))
		error_one("invalid map.\n", game);
	return (1);
}

static int	is_ber(const char *str)
{
	char	*tmp;
	int		a;

	a = 0;
	if (str)
	{
		tmp = ft_substr(str, ft_strlen(str) - 4, 4);
		if (ft_strncmp(tmp, ".ber", 4) == 0)
			a = 1;
		free(tmp);
	}
	return (a);
}

int	main(int ac, char **av)
{
	t_game	*game;

	game = (t_game *)malloc(sizeof(t_game));
	if (!game)
		exit(-1);
	init_game(game);
	if (ac != 2)
		error_one("wrong number of arguments.\n", game);
	game->file_name = ft_strdup(av[1]);
	if (!is_ber(game->file_name))
		error_one("wrong file format.\n", game);
	if (open_file(game))
		drawing(game);
	return (0);
}
