/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   init_structs.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/08 21:18:25 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/08 21:18:31 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong.h"

static t_img	*init_texture(t_game *game)
{
	t_img	*text;

	text = (t_img *)malloc(sizeof(t_img));
	if (!text)
		error_func("malloc error.\n", game);
	text->addr = NULL;
	text->bpp = 0;
	text->endian = 0;
	text->h = 0;
	text->w = 0;
	text->line_lenght = 0;
	text->img = NULL;
	return (text);
}

void	init_struct(t_game *game)
{
	game->plr = init_texture(game);
	game->collect = init_texture(game);
	game->exit = init_texture(game);
	game->wall = init_texture(game);
	game->empty = init_texture(game);
	game->key = (t_key *)malloc(sizeof(t_key));
	if (!game->key)
		error_func("malloc error.\n", game);
	init_key(game->key);
}
