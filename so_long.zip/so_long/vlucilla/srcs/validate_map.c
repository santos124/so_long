/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   validate_map.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/08 21:11:04 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/08 21:11:12 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong.h"

static int	is_rectangle(char **map, int lenmap)
{
	int	i;

	i = 0;
	while (i < lenmap - 1)
	{
		if (ft_strlen(map[i]) != ft_strlen(map[i + 1]))
			return (0);
		i++;
	}
	return (1);
}

static int	are_valid_symbols(char **map)
{
	int	i;
	int	j;

	i = 0;
	while (map[i])
	{
		j = 0;
		while (map[i][j])
		{
			if (!check_map_symbol(map[i][j]))
				return (0);
			j++;
		}
		i++;
	}
	return (1);
}

static void	symb_c(t_game *game, int *player, int *exit)
{
	int	i;
	int	j;

	i = -1;
	while (game->map[++i])
	{
		j = -1;
		while (game->map[i][++j])
		{
			if (game->map[i][j] == 'C')
				game->collect_count++;
			if (game->map[i][j] == 'P')
			{
				game->pl_x = j;
				game->pl_y = i;
				(*player)++;
			}
			if (game->map[i][j] == 'E')
				(*exit)++;
		}
	}
}

static int	symbols_count(t_game *game)
{
	int	player;
	int	exit;

	player = 0;
	exit = 0;
	symb_c(game, &player, &exit);
	if (exit > 0 && game->collect_count > 0 && player == 1)
		return (1);
	return (0);
}

int	is_valid_map(t_game *game)
{
	int	i;

	while (game->map[game->h_map])
		game->h_map++;
	if (!is_rectangle(game->map, game->h_map) || !are_valid_symbols(game->map)
		||!symbols_count(game))
		return (0);
	i = 0;
	while (game->map[0][i])
		if (game->map[0][i++] != '1')
			return (0);
	i = 0;
	while (game->map[game->h_map - 1][i])
		if (game->map[game->h_map - 1][i++] != '1')
			return (0);
	i = 0;
	while (++i < game->h_map - 1)
	{
		if (game->map[i][0] != '1')
			return (0);
		if (game->map[i][ft_strlen(game->map[i]) - 1] != '1')
			return (0);
	}
	game->w_map = ft_strlen(game->map[0]);
	return (1);
}
