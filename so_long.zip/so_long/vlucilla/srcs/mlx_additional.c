/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mlx_additional.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/08 20:27:35 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/08 20:29:00 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong.h"

void	the_mlx_pixel_put(t_img *img, int x, int y, int color)
{
	*(unsigned int *)(img->addr + (y * img->line_lenght + x * (img->bpp / 8)))
		= color;
}

unsigned int	the_mlx_pixel_get(t_img *img, int x, int y)
{
	char			*addr;
	unsigned int	pixel;

	addr = img->addr + (y * img->line_lenght + x * (img->bpp / 8));
	pixel = *(unsigned int *)addr;
	return (pixel);
}
