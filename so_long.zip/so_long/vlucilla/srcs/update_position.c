/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   update_position.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/08 20:31:31 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/08 20:38:02 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong.h"

void	move_left(t_game *game)
{
	if (game->map[game->pl_y][game->pl_x - 1] != '1')
	{
		game->pl_x -= 1;
		if (game->map[game->pl_y][game->pl_x] == 'C')
		{
			game->map[game->pl_y][game->pl_x] = '0';
			game->collect_count--;
		}
		if (game->map[game->pl_y][game->pl_x] == 'E' &&
				game->collect_count == 0)
			exit_game(game);
		game->move++;
		printf("%d\n", game->move);
	}
}

void	move_right(t_game *game)
{
	if (game->map[game->pl_y][game->pl_x + 1] != '1')
	{
		if (game->map[game->pl_y][game->pl_x + 1] == 'C')
		{
			game->map[game->pl_y][game->pl_x + 1] = '0';
			game->collect_count--;
		}
		if (game->map[game->pl_y][game->pl_x + 1] == 'E' &&
				game->collect_count <= 0)
			exit_game(game);
		game->pl_x += 1;
		game->move++;
		printf("%d\n", game->move);
	}
}

void	move_up(t_game *game)
{
	if (game->map[game->pl_y - 1][game->pl_x] != '1')
	{
		if (game->map[game->pl_y - 1][game->pl_x] == 'C')
		{
			game->map[game->pl_y - 1][game->pl_x] = '0';
			game->collect_count--;
		}
		if (game->map[game->pl_y - 1][game->pl_x] == 'E' &&
				game->collect_count <= 0)
			exit_game(game);
		game->pl_y -= 1;
		game->move++;
		printf("%d\n", game->move);
	}
}

void	move_down(t_game *game)
{
	if (game->map[game->pl_y + 1][game->pl_x] != '1')
	{
		if (game->map[game->pl_y + 1][game->pl_x] == 'C')
		{
			game->map[game->pl_y + 1][game->pl_x] = '0';
			game->collect_count--;
		}
		if (game->map[game->pl_y + 1][game->pl_x] == 'E' &&
				game->collect_count <= 0)
			exit_game(game);
		game->pl_y += 1;
		game->move++;
		printf("%d\n", game->move);
	}
}
