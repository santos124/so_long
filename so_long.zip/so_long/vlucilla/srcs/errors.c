/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   errors.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/08 21:16:58 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/08 21:17:10 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong.h"

void	error_func(char *str, t_game *game)
{
	if (game)
		free_game(game);
	printf(RED "Error" RESET "\n");
	printf(MAGENTA "Ooops! Something went wrong!" RESET "\n\n");
	printf(YELLOW "          ／フ 　  フ\n　　　　　| 　_　 _|\n"
		"　 　　　／`ミ _x 彡\n　　 　 /　　　 　 |\n　　　 /　 ヽ　　 ﾉ\n"
		"　／￣|　　 |　|　|\n　| (￣ヽ＿_ヽ_)_)\n　＼二つ              " RESET);
	printf("%s", str);
	exit(1);
}

void	error_one(char *str, t_game *game)
{
	if (game)
		free_part(game);
	printf(RED "Error" RESET "\n");
	printf(MAGENTA "Ooops! Something went wrong!" RESET "\n\n");
	printf(YELLOW "          ／フ 　  フ\n　　　　　| 　_　 _|\n"
		"　 　　　／`ミ _x 彡\n　　 　 /　　　 　 |\n　　　 /　 ヽ　　 ﾉ\n"
		"　／￣|　　 |　|　|\n　| (￣ヽ＿_ヽ_)_)\n　＼二つ              " RESET);
	printf("%s", str);
	exit(1);
}
