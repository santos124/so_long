/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solong.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/08 21:20:15 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/09 18:53:49 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SOLONG_H
# define SOLONG_H

# include "libft.h"
# include <stdlib.h>
# include <stdio.h>
# include <unistd.h>
# include <fcntl.h>
# include <mlx.h>

# define KEY_W 13
# define KEY_S 1
# define KEY_A 0
# define KEY_D 2
# define KEY_ESC 53
# define MAGENTA "\x1b[35m"
# define RED     "\x1b[31m"
# define YELLOW  "\x1b[33m"
# define RESET   "\x1b[0m"
# define BUFFER_SIZE 32

typedef struct s_key
{
	int	up;
	int	down;
	int	left;
	int	right;
	int	esq;
}				t_key;

typedef struct s_img
{
	void	*img;
	char	*addr;
	int		bpp;
	int		line_lenght;
	int		endian;
	int		w;
	int		h;
}				t_img;

typedef struct s_game
{
	char	**map;
	char	*strmap;
	char	*file_name;
	int		pl_x;
	int		pl_y;
	int		collect_count;
	int		h_map;
	int		w_map;
	int		move;
	void	*mlx;
	void	*win;
	t_img	*img;
	t_img	*wall;
	t_img	*exit;
	t_img	*plr;
	t_img	*empty;
	t_img	*collect;
	t_key	*key;
}				t_game;

void			error_func(char *str, t_game *game);
void			free_game(t_game *game);
void			read_map(int fd, t_game *game);
int				create_map(t_game *game);
int				is_valid_map(t_game *game);
int				get_next_line(int fd, char **line);
int				check_map_symbol(char ch);
void			drawing(t_game *game);
void			hook_solong(t_game *game);
int				key_release(int key, t_game *game);
int				key_press(int key, t_game *game);
void			init_key(t_key *key);
int				exit_game(t_game *game);
void			update_player(t_game *game);
void			move_left(t_game *game);
void			move_right(t_game *game);
void			move_up(t_game *game);
void			move_down(t_game *game);
void			draw_field(t_game *game);
void			the_mlx_pixel_put(t_img *img, int x, int y, int color);
unsigned int	the_mlx_pixel_get(t_img *img, int x, int y);
void			init_struct(t_game *game);
void			free_part(t_game *game);
void			error_one(char *str, t_game *game);

#endif
