/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   libft.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/18 04:19:05 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/07 22:15:56 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LIBFT_H
# define LIBFT_H
# include <unistd.h>
# include <stdlib.h>

char	*ft_strtrim(char const *s1, char const *set);
size_t	ft_strlen(const char *c);
char	*ft_strdup(const char *s1);
char	*ft_strchr(const char *s, int ch);
char	*ft_strrchr(const char *s, int ch);
int		ft_strncmp(const char *s1, const char *s2, size_t n);
int		ft_atoi(const char *s);
int		ft_isalpha(int c);
int		ft_isdigit(int c);
char	*ft_substr(const char *s, unsigned int start, size_t len);
char	*ft_strjoin(const char *s1, const char *s2);
char	**ft_split(char const *s, char c);
int		ft_isspace(int ch);
char	*ft_itoa(int n);

#endif
