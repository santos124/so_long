/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free_bonus.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/09 15:57:54 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/09 16:00:19 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong_bonus.h"

static void	free_array(char **arr)
{
	int	i;

	i = 0;
	while (arr[i] != 0)
	{
		free(arr[i]);
		i++;
	}
	free(arr);
	arr = NULL;
}

void	free_text(void *mlx, t_img *text)
{
	if (text->img)
	{
		mlx_destroy_image(mlx, text->img);
		text->img = NULL;
	}
	free(text);
	text = NULL;
}

void	free_part(t_game *game)
{
	if (game->strmap)
	{
		free(game->strmap);
		game->strmap = NULL;
	}
	if (game->map)
		free_array(game->map);
	if (game->file_name)
	{
		free(game->file_name);
		game->file_name = NULL;
	}
	free(game);
	game = NULL;
}

static void	free_textures_images(t_game *game)
{
	if (game->collect)
		free_text(game->mlx, game->collect);
	if (game->wall)
		free_text(game->mlx, game->wall);
	if (game->plr)
		free_text(game->mlx, game->plr);
	if (game->exit)
		free_text(game->mlx, game->exit);
	if (game->empty)
		free_text(game->mlx, game->empty);
	if (game->enemy)
		free_text(game->mlx, game->enemy);
}

void	free_game(t_game *game)
{
	if (game->strmap)
	{
		free(game->strmap);
		game->strmap = NULL;
	}
	if (game->map)
		free_array(game->map);
	if (game->file_name)
	{
		free(game->file_name);
		game->file_name = NULL;
	}
	mlx_destroy_image(game->mlx, game->img->img);
	mlx_clear_window(game->mlx, game->win);
	free_textures_images(game);
	if (game->key)
	{
		free(game->key);
		game->key = NULL;
	}
	free(game);
	game = NULL;
}
