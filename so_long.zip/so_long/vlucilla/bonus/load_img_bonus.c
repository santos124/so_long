/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   load_img_bonus.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/09 16:02:24 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/09 16:07:36 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong_bonus.h"

static void	draw_rectangle(t_game *game, t_img *img, int i, int j)
{
	int				x;
	int				y;
	unsigned int	color;

	y = 0;
	while (y < 64)
	{
		x = 0;
		while (x < 64)
		{
			color = the_mlx_pixel_get(img, x, y);
			if ((color & 0x00FFFFFF) != 0)
				the_mlx_pixel_put(game->img, j + x, i + y, color);
			x++;
		}
		y++;
	}
}

static void	draw_objects(t_game *game, int i, int j)
{
	static int	dif = 0;
	static int	flag = 0;

	if (dif > 10000)
		flag = 0;
	else if (dif < -10000)
		flag = 1;
	if (flag)
		dif++;
	else
		dif--;
	if (game->map[i][j] == 'C')
		draw_rectangle(game, game->collect, i * 64, j * 64 + dif / 1000);
	if (game->map[i][j] == 'E')
		draw_rectangle(game, game->exit, i * 64, j * 64);
	if (game->map[i][j] == 'X')
		draw_rectangle(game, game->enemy, i * 64, j * 64);
	if (i == game->pl_y && j == game->pl_x)
		draw_rectangle(game, game->plr, i * 64, j * 64);
}

void	draw_field(t_game *game)
{
	int	i;
	int	j;

	i = 0;
	while (game->map[i])
	{
		j = 0;
		while (game->map[i][j])
		{
			if (game->map[i][j] == '1')
				draw_rectangle(game, game->wall, i * 64, j * 64);
			else
				draw_rectangle(game, game->empty, i * 64, j * 64);
			draw_objects(game, i, j);
			j++;
		}
		i++;
	}
}
