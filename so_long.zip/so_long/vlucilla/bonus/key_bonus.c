/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   key_bonus.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/09 16:02:06 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/09 16:02:08 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong_bonus.h"

void	init_key(t_key *key)
{
	key->down = 0;
	key->up = 0;
	key->esq = 0;
	key->left = 0;
	key->right = 0;
}

int	key_press(int key, t_game *game)
{
	if (!game->lose)
	{
		if (key == KEY_S && !game->key->down)
			move_down(game);
		if (key == KEY_W && !game->key->up)
			move_up(game);
		if (key == KEY_A && !game->key->left)
			move_left(game);
		if (key == KEY_D && !game->key->right)
			move_right(game);
	}
	if (key == KEY_ESC && !game->key->esq)
		exit_game(game);
	return (0);
}

int	key_release(int key, t_game *game)
{
	if (key == KEY_S && game->key->down)
		game->key->down = 0;
	if (key == KEY_W && game->key->up)
		game->key->up = 0;
	if (key == KEY_A && game->key->left)
		game->key->left = 0;
	if (key == KEY_D && game->key->right)
		game->key->right = 0;
	return (0);
}
