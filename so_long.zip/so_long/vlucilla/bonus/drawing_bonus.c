/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   drawing_bonus.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/09 15:53:15 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/09 15:55:38 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong_bonus.h"

int	get_texture(void *mlx, t_img *text, char *filename)
{
	text->img = mlx_xpm_file_to_image(mlx, filename, &text->w, &text->h);
	if (!text->img)
		return (0);
	text->addr = mlx_get_data_addr(text->img, &text->bpp,
			&text->line_lenght, &text->endian);
	return (1);
}

static int	check_text(t_game *game)
{
	if (!get_texture(game->mlx, game->collect, "./textures/collect.xpm"))
		return (0);
	if (!get_texture(game->mlx, game->empty, "./textures/empty.xpm"))
		return (0);
	if (!get_texture(game->mlx, game->exit, "./textures/exit.xpm"))
		return (0);
	if (!get_texture(game->mlx, game->plr, "./textures/plr.xpm"))
		return (0);
	if (!get_texture(game->mlx, game->wall, "./textures/wall.xpm"))
		return (0);
	if (!get_texture(game->mlx, game->enemy, "./textures/enemy.xpm"))
		return (0);
	return (1);
}

void	drawing(t_game *game)
{
	init_struct(game);
	game->mlx = mlx_init();
	if (!game->mlx)
		error_func("mlx error.\n", game);
	game->win = mlx_new_window(game->mlx, game->w_map * 64,
			game->h_map * 64, "so_long");
	if (!game->win)
		error_func("mlx error.\n", game);
	game->img = (t_img *)malloc(sizeof(t_img));
	if (!game->img)
		error_func("mlx error.\n", game);
	game->img->img = mlx_new_image(game->mlx,
			game->w_map * 64, game->h_map * 64);
	if (!game->img->img)
		error_func("mlx error.\n", game);
	game->img->addr = mlx_get_data_addr(game->img->img, &game->img->bpp,
			&game->img->line_lenght, &game->img->endian);
	if (!check_text(game))
		error_func("textures error.\n", game);
	hook_solong(game);
}
