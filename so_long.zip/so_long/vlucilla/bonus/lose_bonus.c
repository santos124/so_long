/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lose_bonus.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/09 16:07:44 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/09 16:12:48 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong_bonus.h"

static int	exit_all(t_game *game)
{
	mlx_destroy_image(game->mlx, game->lose->img->img);
	mlx_clear_window(game->mlx, game->lose->win);
	free_game(game);
	exit (1);
	return (0);
}

static void	init_lose(t_lose *lose)
{
	lose->win = NULL;
	lose->img = NULL;
	lose->esq = 0;
}

static int	esq_press(int key, t_game *game)
{
	if (key == KEY_ESC && !game->lose->esq)
		exit_all(game);
	return (0);
}

void	lose_game(t_game *game)
{
	game->lose = (t_lose *)malloc(sizeof(t_lose));
	if (!game->lose)
		error_func("malloc error.\n", game);
	init_lose(game->lose);
	game->lose->img = init_texture(game);
	if (!get_texture(game->mlx, game->lose->img, "./textures/lose.xpm"))
		error_func("malloc error.\n", game);
	game->lose->win = mlx_new_window(game->mlx, game->lose->img->w,
			game->lose->img->h, "Loose");
	mlx_put_image_to_window(game->mlx, game->lose->win,
		game->lose->img->img, 0, 0);
	mlx_hook(game->lose->win, 17, 1L << 17, &exit_all, game);
	mlx_hook(game->lose->win, 2, 1L << 0, &esq_press, game);
	mlx_loop(game->mlx);
}
