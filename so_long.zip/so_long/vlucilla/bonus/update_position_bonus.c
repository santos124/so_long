/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   update_position_bonus.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/09 16:17:01 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/09 16:22:36 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong_bonus.h"

void	move_left(t_game *game)
{
	if (game->map[game->pl_y][game->pl_x - 1] != '1')
	{
		game->pl_x -= 1;
		game->move++;
		if (game->map[game->pl_y][game->pl_x] == 'C')
		{
			game->map[game->pl_y][game->pl_x] = '0';
			game->collect_count--;
		}
		if (game->map[game->pl_y][game->pl_x] == 'E' &&
				game->collect_count <= 0)
			exit_game(game);
		if (game->map[game->pl_y][game->pl_x] == 'X')
			lose_game(game);
	}
}

void	move_right(t_game *game)
{
	if (game->map[game->pl_y][game->pl_x + 1] != '1')
	{
		game->pl_x += 1;
		game->move++;
		if (game->map[game->pl_y][game->pl_x] == 'C')
		{
			game->map[game->pl_y][game->pl_x] = '0';
			game->collect_count--;
		}
		if (game->map[game->pl_y][game->pl_x] == 'E' &&
				game->collect_count <= 0)
			exit_game(game);
		if (game->map[game->pl_y][game->pl_x] == 'X')
			lose_game(game);
	}
}

void	move_up(t_game *game)
{
	if (game->map[game->pl_y - 1][game->pl_x] != '1')
	{
		game->pl_y -= 1;
		game->move++;
		if (game->map[game->pl_y][game->pl_x] == 'C')
		{
			game->map[game->pl_y][game->pl_x] = '0';
			game->collect_count--;
		}
		if (game->map[game->pl_y][game->pl_x] == 'E' &&
				game->collect_count <= 0)
			exit_game(game);
		if (game->map[game->pl_y][game->pl_x] == 'X')
			lose_game(game);
	}
}

void	move_down(t_game *game)
{
	if (game->map[game->pl_y + 1][game->pl_x] != '1')
	{
		game->pl_y += 1;
		game->move++;
		if (game->map[game->pl_y][game->pl_x] == 'C')
		{
			game->map[game->pl_y][game->pl_x] = '0';
			game->collect_count--;
		}
		if (game->map[game->pl_y][game->pl_x] == 'E' &&
				game->collect_count <= 0)
			exit_game(game);
		if (game->map[game->pl_y][game->pl_x] == 'X')
			lose_game(game);
	}
}
