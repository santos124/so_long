/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   hook_start_bonus.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/09 16:00:47 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/09 16:01:21 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong_bonus.h"

static int	start_solong(t_game *game)
{
	char	*str;

	str = NULL;
	draw_field(game);
	mlx_put_image_to_window(game->mlx, game->win, game->img->img, 0, 0);
	str = ft_itoa(game->move);
	mlx_string_put(game->mlx, game->win, 75, 75, 0xFF0000, str);
	free(str);
	return (1);
}

int	exit_game(t_game *game)
{
	free_game(game);
	exit (0);
}

void	hook_solong(t_game *game)
{
	mlx_do_key_autorepeatoff(game->mlx);
	mlx_hook(game->win, 2, 1L << 0, &key_press, game);
	mlx_hook(game->win, 3, 1L << 1, &key_release, game);
	mlx_hook(game->win, 17, 0, &exit_game, game);
	mlx_loop_hook(game->mlx, start_solong, game);
	mlx_loop(game->mlx);
}
