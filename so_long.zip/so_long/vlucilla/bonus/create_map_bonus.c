/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_map_bonus.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/09 16:27:54 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/09 16:28:35 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong_bonus.h"

int	check_map_symbol(char ch)
{
	if (ch == 'P' || ch == 'C' || ch == 'E' || ch == '0'
		|| ch == '1' || ch == 'X')
		return (1);
	return (0);
}

static int	check_n(char *line)
{
	int	i;

	i = 0;
	while (line[i])
	{
		if (line[i] == '\n')
		{
			if (!check_map_symbol(line[i + 1]))
				return (0);
		}
		i++;
	}
	return (1);
}

int	create_map(t_game *game)
{
	char	*trim;

	trim = ft_strtrim(game->strmap, "\n");
	if (!trim)
		error_one("memory allocation fail.\n", game);
	if (!check_n(trim))
	{
		free(trim);
		return (0);
	}
	game->map = ft_split(game->strmap, '\n');
	if (!game->map)
	{
		free(trim);
		return (0);
	}
	free(trim);
	return (1);
}
