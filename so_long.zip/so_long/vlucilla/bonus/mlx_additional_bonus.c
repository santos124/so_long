/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   mlx_additional_bonus.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: vlucilla <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/09/09 16:14:57 by vlucilla          #+#    #+#             */
/*   Updated: 2021/09/09 16:15:51 by vlucilla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "solong_bonus.h"

void	the_mlx_pixel_put(t_img *img, int x, int y, int color)
{
	*(unsigned int *)(img->addr + (y * img->line_lenght + x * (img->bpp / 8)))
		= color;
}

unsigned int	the_mlx_pixel_get(t_img *img, int x, int y)
{
	char			*addr;
	unsigned int	pixel;

	addr = img->addr + (y * img->line_lenght + x * (img->bpp / 8));
	pixel = *(unsigned int *)addr;
	return (pixel);
}
